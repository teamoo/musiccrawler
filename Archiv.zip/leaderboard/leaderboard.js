// Set up a collection to contain player information. On the server,
// it is backed by a MongoDB collection named "players".

Links = new Meteor.Collection("links");

if (Meteor.isClient) {
  Template.musiccrawler.links = function () {
      return Links.find({}, {sort: {date: 1, name: 1, url:1}});
  };

  Template.musiccrawler.selected_name = function () {
    var link = Links.findOne(Session.get("selected_link"));
    return link && link.name;
  };

  Template.link.selected = function () {
    return Session.equals("selected_link", this._id) ? "selected" : '';
  };

  Template.musiccrawler.events({
    'click input.inc': function () {
      Links.update(Session.get("selected_link"), {$inc: {score: 10}});
    }
  });

  Template.link.events({
    'click': function () {
      Session.set("selected_link", this._id);
    }
  });
}

// On server startup, create some players if the database is empty.
if (Meteor.isServer) {
  Meteor.startup(function () {
  });
}