<?php
require 'D:/xampp/htdocs/musiccrawlerweb/Slim/Slim.php';
require 'D:/xampp/htdocs/musiccrawlerweb/NotORM/NotORM.php';
\Slim\Slim::registerAutoloader();

$dsn = "mysql:host=localhost;dbname=musiclinksql2";
$username = "root";
$password = "HOME4lsyas@lh";

$pdo = new PDO($dsn, $username, $password);
$db = new NotORM($pdo);
$app = new \Slim\Slim();
	
$app->get('/hello/:name', function ($name) {
    echo "Hello, $name";
});	
	
$app->get("/links", function () use ($app, $db) {
    $links = array();
    foreach ($db->links() as $link) {
        $links[]  = array(
            "id" => $link["id"],
            "url" => $link["url"],
            "name" => $link["name"],
			"size" => $link["size"],
			"status" => $link["status"],
			"source" => $link["source"],
            "date" => $link["date"],
			"hoster" => $link["hoster"],
			"password" => $link["password"],
            "metainfo" => $link["metainfo"]
        );
    }
    $app->response()->header("Content-Type", "application/json");
    echo json_encode($links);
});

$app->get("/link/:id", function ($id) use ($app, $db) {
    $app->response()->header("Content-Type", "application/json");
    $link = $db->links()->where("id", $id);
    if ($data = $link->fetch()) {
        echo json_encode(array(
            "id" => $data["id"],
            "url" => $data["url"],
            "name" => $data["name"],
			"size" => $data["size"],
			"status" => $data["status"],
			"source" => $data["source"],
            "date" => $data["date"],
			"hoster" => $data["hoster"],
			"password" => $data["password"],
            "metainfo" => $data["metainfo"]
            ));
    }
    else{
        echo json_encode(array(
            "status" => false,
            "message" => "link ID $id does not exist"
            ));
    }
});

$app->post("/link", function () use ($app, $db) {
    $app->response()->header("Content-Type", "application/json");
    $link = $app->request()->post();
    $result = $db->links->insert($link);
    echo json_encode(array("id" => $result["id"]));
});

$app->put("/link/:id", function ($id) use ($app, $db) {
    $app->response()->header("Content-Type", "application/json");
    $link = $db->links()->where("id", $id);
    if ($link->fetch()) {
        $put = $app->request()->put();
        $result = $link->update($put);
        echo json_encode(array(
            "status" => (bool)$result,
            "message" => "link updated successfully"
            ));
    }
    else{
        echo json_encode(array(
            "status" => false,
            "message" => "link id $id does not exist"
        ));
    }
});

$app->delete("/link/:id", function ($id) use($app, $db) {
    $app->response()->header("Content-Type", "application/json");
    $link = $db->links()->where("id", $id);
    if ($link->fetch()) {
        $result = $link->delete();
        echo json_encode(array(
            "status" => true,
            "message" => "link deleted successfully"
        ));
    }
    else{
        echo json_encode(array(
            "status" => false,
            "message" => "link id $id does not exist"
        ));
    }
});

$app->run();