var App = Ember.Application.create();

App.ApplicationController = Ember.Controller.extend();
App.ApplicationView = Ember.View.extend({
  templateName: 'application'
});

App.Router = Ember.Router.extend({
  root: Ember.Route.extend({
    index: Ember.Route.extend({
      route: '/'
    })
  })
});

App.Store = DS.Store.extend({
  revision: 11
});

var attr = DS.attr;

App.Link = DS.Model.extend({
  id: attr('number'),
  url: attr('string'),
  name: attr('string'),
  size: attr('number'),
  status: attr('string'),
  source: attr('string'),
  hoster: attr('string'),
  date: attr('date') 
});


App.initialize();


var links = App.Link.find();