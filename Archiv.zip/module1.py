import feedparser
import re
import json
import sys
import math
from array import array
import time
from datetime import date
from time import mktime
from datetime import datetime
import monthdelta


reload(sys)
sys.setdefaultencoding( "utf-8" )

rssFeeds = [
            #"http://whatdjplays.com/feed",
            #"http://electrouniverse.net/feed",
            "http://feeds.feedburner.com/HouseRavers",
            #"http://www.exclusive-music-dj.com/feed",
            #"http://oradeaclubmusic.blogspot.de/feeds/posts/default",
            #"http://feeds.feedburner.com/djrobsonmichel/YSqR",
            #"http://cahulhousemafia.net/feed",
            #"http://electropeople.org/rss.xml",
            #"http://www.club-box-11.blogspot.com/feeds/posts/default",
            #"http://mypromosound.com/feed/",
            #"http://electro.dadabeat.com/feed"
]



for feedurl in rssFeeds:
    print "ok"

    rssFeed = feedparser.parse(feedurl)
    
    if rssFeed.bozo == 1:
        print "Feed kann nicht verarbeitet werden:", feedurl
    else:
        y_diff = datetime.now().year - datetime.fromtimestamp(mktime(rssFeed.entries[0].published_parsed)).year
        print y_diff
        m_diff = datetime.now().month - datetime.fromtimestamp(mktime(rssFeed.entries[0].published_parsed)).month + (12 * y_diff)
        print  m_diff

        print (datetime.now() - monthdelta.MonthDelta(6)) < datetime.fromtimestamp(mktime(rssFeed.entries[0].published_parsed))
 